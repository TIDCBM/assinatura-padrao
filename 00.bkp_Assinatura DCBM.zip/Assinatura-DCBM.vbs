' ---------------------------------------------------------------------------
'  Assinatura DCBM - execucao sem janela de console
'
'  Use este arquivo no dia a dia: abre direto na tela de opcoes, sem a janela
'  preta ao fundo. As mensagens que apareceriam no console ficam gravadas em
'  Logs\console_*.log.
'
'  Para acompanhar a execucao na tela, use o Assinatura-DCBM.cmd.
' ---------------------------------------------------------------------------

Option Explicit

Dim sh, fso, pasta, script, comando

Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

pasta  = fso.GetParentFolderName(WScript.ScriptFullName)
script = fso.BuildPath(pasta, "Assinatura-DCBM.ps1")

If Not fso.FileExists(script) Then
    MsgBox "Assinatura-DCBM.ps1 nao encontrado em:" & vbCrLf & vbCrLf & pasta, _
           vbCritical, "Assinatura DCBM"
    WScript.Quit 1
End If

comando = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & script & """"

' 0 = janela oculta   False = nao espera terminar
sh.Run comando, 0, False
