<#
.SYNOPSIS
    Assinatura padronizada DCBM - aplicacao no Office 365 e no Outlook classico.

.DESCRIPTION
    Ao executar, apresenta duas opcoes:

      1. Alterar no Office 365
         Carrega os usuarios com caixa postal do Exchange Online, mostra numa grade
         com filtro e caixas de selecao, e grava a assinatura apenas nos marcados.

      2. Alterar no Outlook Classic
         Le os dados do usuario logado direto do AD local e instala a assinatura
         em %APPDATA%\Microsoft\Signatures, definindo-a como padrao.

    Os modelos e as imagens ficam no GitHub. O script baixa com_celular.html e
    sem_celular.html a cada execucao, entao alterar o visual e questao de
    atualizar o repositorio - nenhuma estacao precisa ser tocada.

    O modelo e escolhido pelo atributo de celular do diretorio:
      preenchido -> com_celular.html
      vazio      -> sem_celular.html

    IMPORTANTE: as imagens devem estar referenciadas por URL https no modelo.
    O Exchange esvazia o src de imagens em base64.

.EXAMPLE
    .\Assinatura-DCBM.ps1

.EXAMPLE
    .\Assinatura-DCBM.ps1 -Modo Classic
#>

[CmdletBinding()]
param(
    [ValidateSet('Menu','Office365','Classic','Cache')]
    [string] $Modo = 'Menu',

    [string] $BaseUrl        = 'https://tidcbm.github.io/assinatura-padrao',
    [string] $NomeAssinatura = 'DCBM',
    [string] $PastaLogs,

    # Usa a copia local quando ela existir, sem consultar o GitHub.
    # Atalho para rede ruim. Alteracoes publicadas no GitHub nao chegam.
    [switch] $PreferirLocal
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------------------------------------------------------------------------
# Pastas
# ---------------------------------------------------------------------------

$raiz = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

function Test-PodeGravar {
    <#
      Confirma gravacao de verdade, criando e apagando um arquivo. Testar apenas
      a existencia da pasta nao basta: em compartilhamento de rede o usuario
      comum costuma ter leitura, mas nao escrita.
    #>
    param([string]$Pasta)
    try {
        if (-not (Test-Path -LiteralPath $Pasta)) {
            New-Item -ItemType Directory -Path $Pasta -Force -ErrorAction Stop | Out-Null
        }
        $teste = Join-Path $Pasta ('.escrita_{0}.tmp' -f [guid]::NewGuid().ToString('N').Substring(0,8))
        [IO.File]::WriteAllText($teste, 'ok')
        Remove-Item -LiteralPath $teste -Force -ErrorAction SilentlyContinue
        return $true
    }
    catch { return $false }
}

if (-not $PastaLogs) {
    # 1o: ao lado do script. Serve quando a TI roda de uma pasta propria.
    # 2o: perfil local. Necessario quando o script vem de compartilhamento
    #     somente leitura, que e o caso do usuario comum.
    $candidataRede  = Join-Path $raiz 'Logs'
    $candidataLocal = Join-Path $env:LOCALAPPDATA 'DCBM\Assinatura\Logs'

    if (Test-PodeGravar -Pasta $candidataRede) {
        $PastaLogs = $candidataRede
    }
    else {
        $PastaLogs = $candidataLocal
        Write-Host ("Sem permissao de escrita em '{0}'." -f $candidataRede) -ForegroundColor DarkGray
        Write-Host ("Logs desta execucao em: {0}" -f $PastaLogs) -ForegroundColor DarkGray
        if (-not (Test-PodeGravar -Pasta $PastaLogs)) {
            throw "Nao ha onde gravar os logs. Tentei:`n  $candidataRede`n  $candidataLocal"
        }
    }
}
elseif (-not (Test-PodeGravar -Pasta $PastaLogs)) {
    throw "Sem permissao de escrita na pasta informada em -PastaLogs: $PastaLogs"
}

$PastaPreview = Join-Path $PastaLogs 'Preview'
if (-not (Test-Path -LiteralPath $PastaPreview)) {
    New-Item -ItemType Directory -Path $PastaPreview -Force | Out-Null
}

# Guarda tudo o que sairia no console. Como a janela preta fica oculta na
# execucao normal, este arquivo e onde se olha quando algo da errado.
try {
    Start-Transcript -Path (Join-Path $PastaLogs ("console_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))) `
                     -Force | Out-Null
} catch { }

function Write-Log {
    param([object[]]$Registros, [string]$Rotulo)

    if (-not $Registros -or $Registros.Count -eq 0) { return $null }
    $arq = Join-Path $PastaLogs ("log_{0}_{1}.csv" -f $Rotulo.ToLower(), (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $Registros | Export-Csv -LiteralPath $arq -NoTypeInformation -Encoding UTF8
    return $arq
}

# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------

function Get-Template {
    <#
      O GitHub e a fonte oficial. A cada execucao o modelo e baixado de la e a
      copia local e regravada, entao o plano B nunca envelhece sozinho.

      Se o GitHub estiver inacessivel, usa a copia local e avisa em amarelo.
      Com -PreferirLocal, inverte: usa a copia local quando ela existir e so vai
      a rede se ela faltar. Mais rapido, porem alteracoes publicadas no GitHub
      deixam de chegar - use apenas em situacao de rede ruim.
    #>
    param([string]$Arquivo, [string]$Rotulo)

    $pastaModelos = Join-Path $raiz 'Arquivos de Modelo'
    $localPadrao  = Join-Path $pastaModelos $Arquivo

    $candidatos = @($localPadrao, (Join-Path $raiz $Arquivo))
    $local = $candidatos | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

    $txt = $null
    $url = "$BaseUrl/$Arquivo"

    # Modo local primeiro, quando pedido explicitamente
    if ($PreferirLocal -and $local) {
        $txt = Get-Content -LiteralPath $local -Raw -Encoding UTF8
        Write-Host ("Modelo '{0}': usando copia local (-PreferirLocal)." -f $Rotulo) -ForegroundColor Yellow
    }
    else {
        try {
            [Net.ServicePointManager]::SecurityProtocol =
                [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            $resp = Invoke-WebRequest -Uri ("{0}?v={1}" -f $url, (Get-Date -Format 'yyyyMMddHHmmss')) `
                        -UseBasicParsing -TimeoutSec 30
            $txt = [string]$resp.Content

            # Mantem a copia local sincronizada com o que acabou de vir do GitHub
            try {
                if (-not (Test-Path -LiteralPath $pastaModelos)) {
                    New-Item -ItemType Directory -Path $pastaModelos -Force | Out-Null
                }
                $atual = if (Test-Path -LiteralPath $localPadrao) {
                    [IO.File]::ReadAllText($localPadrao)
                } else { '' }

                if (($atual -replace '\s+', ' ').Trim() -ne ($txt -replace '\s+', ' ').Trim()) {
                    [IO.File]::WriteAllText($localPadrao, $txt, (New-Object Text.UTF8Encoding $false))
                    Write-Host ("Modelo '{0}' baixado do GitHub. Copia local atualizada." -f $Rotulo) -ForegroundColor Green
                }
                else {
                    Write-Host ("Modelo '{0}' baixado do GitHub. Copia local ja estava igual." -f $Rotulo) -ForegroundColor DarkGray
                }
            }
            catch {
                Write-Host ("Modelo '{0}' baixado, mas nao foi possivel gravar a copia local: {1}" -f `
                            $Rotulo, $_.Exception.Message) -ForegroundColor Yellow
            }
        }
        catch {
            if ($local) {
                $txt = Get-Content -LiteralPath $local -Raw -Encoding UTF8
                Write-Host ("Modelo '{0}': GitHub indisponivel, usando copia local." -f $Rotulo) -ForegroundColor Yellow
            }
            else {
                throw ("Modelo '{0}' nao pode ser obtido. URL: {1}{2}Nem existe copia local em:{2}  {3}" -f `
                       $Rotulo, $url, [Environment]::NewLine, ($candidatos -join ([Environment]::NewLine + '  ')))
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($txt))  { throw "Modelo '$Rotulo' esta vazio: $url" }
    if ($txt -notmatch '%%DisplayName%%')    { throw "Modelo '$Rotulo' nao contem %%DisplayName%%: $url" }
    if ($txt -match 'src="data:image')       { throw "Modelo '$Rotulo' usa base64. O Exchange apaga o src. Use URL https." }

    return $txt
}

function Import-Templates {
    Write-Host 'Carregando modelos...' -ForegroundColor Cyan
    return @{
        ComCelular = Get-Template -Arquivo 'com_celular.html' -Rotulo 'com celular'
        SemCelular = Get-Template -Arquivo 'sem_celular.html' -Rotulo 'sem celular'
    }
}

# ---------------------------------------------------------------------------
# Montagem do HTML
# ---------------------------------------------------------------------------

function ConvertTo-SafeHtml {
    param([object]$Valor)
    if ($null -eq $Valor) { return '' }
    return [System.Net.WebUtility]::HtmlEncode([string]$Valor)
}

function Build-Signature {
    <#
      Recebe o dicionario de campos ja resolvido (venha do Exchange ou do AD) e
      devolve o HTML pronto, a lista de campos vazios e se sobrou placeholder.
    #>
    param(
        [hashtable]$Campos,
        [hashtable]$Templates
    )

    $temCelular = -not [string]::IsNullOrWhiteSpace([string]$Campos['%%MobileNumber%%'])
    $html = if ($temCelular) { $Templates['ComCelular'] } else { $Templates['SemCelular'] }

    $faltando = @()
    foreach ($chave in $Campos.Keys) {
        if ($chave -eq '%%MobileNumber%%' -and -not $temCelular) { continue }
        if ($html.Contains($chave) -and [string]::IsNullOrWhiteSpace([string]$Campos[$chave])) {
            $faltando += $chave.Trim('%')
        }
        $html = $html.Replace($chave, (ConvertTo-SafeHtml $Campos[$chave]))
    }

    # Sobras quando o cadastro esta incompleto
    if ([string]::IsNullOrWhiteSpace([string]$Campos['%%FaxNumber%%'])) {
        $html = $html -replace '\s*Ext\.\s*(?=<)', ''
    }
    if ([string]::IsNullOrWhiteSpace([string]$Campos['%%PhoneNumber%%'])) {
        $html = $html -replace '(?<=>)\s*\+\s*(?=[A-Za-z<])', ''
    }
    $html = $html -replace '\+{2,}', '+'

    return [pscustomobject]@{
        Html       = $html
        TemCelular = $temCelular
        Faltando   = ($faltando -join '; ')
        Sobrou     = ($html -match '%%\w+%%')
    }
}

# ---------------------------------------------------------------------------
# Menu inicial
# ---------------------------------------------------------------------------

function Show-Menu {
    $f = New-Object System.Windows.Forms.Form
    $f.Text            = 'Assinatura DCBM'
    $f.Size            = New-Object System.Drawing.Size(560, 400)
    $f.StartPosition   = 'CenterScreen'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox     = $false
    $f.MinimizeBox     = $false

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text     = 'O que voce quer fazer?'
    $lbl.Location = New-Object System.Drawing.Point(20, 18)
    $lbl.Size     = New-Object System.Drawing.Size(505, 24)
    $lbl.Font     = New-Object System.Drawing.Font('Segoe UI', 11)
    $f.Controls.Add($lbl)

    $b1 = New-Object System.Windows.Forms.Button
    $b1.Text      = "Alterar no Office 365"
    $b1.Location  = New-Object System.Drawing.Point(20, 52)
    $b1.Size      = New-Object System.Drawing.Size(505, 56)
    $b1.Font      = New-Object System.Drawing.Font('Segoe UI', 11)
    $b1.BackColor = [System.Drawing.Color]::FromArgb(242, 92, 39)
    $b1.ForeColor = [System.Drawing.Color]::White
    $b1.FlatStyle = 'Flat'
    $b1.Add_Click({ $f.Tag = 'Office365'; $f.Close() })
    $f.Controls.Add($b1)

    $b2 = New-Object System.Windows.Forms.Button
    $b2.Text     = "Alterar no Outlook Classic"
    $b2.Location = New-Object System.Drawing.Point(20, 118)
    $b2.Size     = New-Object System.Drawing.Size(505, 56)
    $b2.Font     = New-Object System.Drawing.Font('Segoe UI', 11)
    $b2.Add_Click({ $f.Tag = 'Classic'; $f.Close() })
    $f.Controls.Add($b2)

    $b3 = New-Object System.Windows.Forms.Button
    $b3.Text     = "Limpar Cache Office"
    $b3.Location = New-Object System.Drawing.Point(20, 184)
    $b3.Size     = New-Object System.Drawing.Size(505, 56)
    $b3.Font     = New-Object System.Drawing.Font('Segoe UI', 11)
    $b3.Add_Click({ $f.Tag = 'Cache'; $f.Close() })
    $f.Controls.Add($b3)

    $lblAjuda = New-Object System.Windows.Forms.Label
    $lblAjuda.Text      = 'Office 365: escolhe usuarios e grava na caixa de correio.' + [Environment]::NewLine +
                          'Outlook Classic: instala a assinatura nesta maquina, para o usuario logado.' + [Environment]::NewLine +
                          'Limpar Cache: limpa o cache do Outlook novo e do classico nesta maquina.'
    $lblAjuda.Location  = New-Object System.Drawing.Point(20, 250)
    $lblAjuda.Size      = New-Object System.Drawing.Size(505, 56)
    $lblAjuda.ForeColor = [System.Drawing.Color]::DimGray
    $f.Controls.Add($lblAjuda)

    $bPasta = New-Object System.Windows.Forms.Button
    $bPasta.Text     = 'Acessar pasta de assinaturas Outlook Classic'
    $bPasta.Location = New-Object System.Drawing.Point(210, 312)
    $bPasta.Size     = New-Object System.Drawing.Size(315, 30)
    $bPasta.Add_Click({
        $pasta = Join-Path $env:APPDATA 'Microsoft\Signatures'
        if (-not (Test-Path -LiteralPath $pasta)) { New-Item -ItemType Directory -Path $pasta -Force | Out-Null }
        Start-Process explorer.exe $pasta
    })
    $f.Controls.Add($bPasta)

    $bSair = New-Object System.Windows.Forms.Button
    $bSair.Text     = 'Sair'
    $bSair.Location = New-Object System.Drawing.Point(20, 312)
    $bSair.Size     = New-Object System.Drawing.Size(100, 30)
    $bSair.Add_Click({ $f.Tag = $null; $f.Close() })
    $f.Controls.Add($bSair)

    [void]$f.ShowDialog()
    return $f.Tag
}

# ---------------------------------------------------------------------------
# Modo 1 - Office 365
# ---------------------------------------------------------------------------

function Initialize-ExchangeOnline {
    <#
      Prepara a frente do Office 365: instala o modulo se faltar, conecta e
      confirma que a conta tem permissao administrativa.

      Instalar so aqui e proposital. A frente Classic nao usa Exchange nenhum,
      e o modulo e grande - nao faz sentido baixa-lo na estacao de um usuario
      que so vai instalar a propria assinatura.

      Devolve $true quando esta tudo pronto.
    #>

    # ------------------------------------------------------------ modulo
    if (-not (Get-Module -ListAvailable -Name ExchangeOnlineManagement)) {
        $r = [System.Windows.Forms.MessageBox]::Show(
@"
O modulo ExchangeOnlineManagement nao esta instalado nesta maquina.

Ele e necessario apenas para a opcao "Alterar no Office 365".
A instalacao e feita no seu perfil e nao exige administrador.

Instalar agora? Pode levar alguns minutos.
"@, 'Assinatura DCBM', 'YesNo', 'Question')

        if ($r -ne 'Yes') { return $false }

        try {
            Write-Host 'Instalando o modulo ExchangeOnlineManagement...' -ForegroundColor Yellow
            [Net.ServicePointManager]::SecurityProtocol =
                [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

            $nuget = Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue
            if (-not $nuget -or $nuget.Version -lt [version]'2.8.5.201') {
                Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force -ErrorAction Stop | Out-Null
            }
            if (-not (Get-PSRepository -Name PSGallery -ErrorAction SilentlyContinue)) {
                Register-PSRepository -Default -ErrorAction Stop
            }
            # -Force evita a pergunta de repositorio nao confiavel, que travaria a execucao
            Install-Module -Name ExchangeOnlineManagement -Scope CurrentUser -Force -AllowClobber -Confirm:$false -ErrorAction Stop
            Write-Host 'Modulo instalado.' -ForegroundColor Green
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
@"
Nao foi possivel instalar o modulo.

$($_.Exception.Message)

Causas comuns: sem internet, proxy bloqueando a PSGallery, ou antivirus.
"@, 'Assinatura DCBM', 'OK', 'Error') | Out-Null
            return $false
        }
    }

    # ------------------------------------------------------------ conexao
    if (-not (Get-Command Get-Mailbox -ErrorAction SilentlyContinue)) {
        try {
            Write-Host 'Conectando ao Exchange Online...' -ForegroundColor Cyan
            Import-Module ExchangeOnlineManagement -ErrorAction Stop
            Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
                ("Nao foi possivel conectar ao Exchange Online." + [Environment]::NewLine + [Environment]::NewLine + $_.Exception.Message),
                'Assinatura DCBM', 'OK', 'Error') | Out-Null
            return $false
        }
    }

    # -------------------------------------------------------- permissao
    # Get-OrganizationConfig exige papel administrativo. Usuario comum conecta
    # normalmente, porem so enxerga a propria caixa - e falharia adiante, com
    # mensagem confusa. Melhor barrar aqui, explicando.
    try { $null = Get-OrganizationConfig -ErrorAction Stop }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
@"
A conta conectada nao tem permissao de administrador no Exchange Online.

Esta opcao aplica a assinatura em varios usuarios e exige um papel
administrativo. Com uma conta comum e possivel ver apenas a propria caixa.

Para instalar a assinatura no seu proprio Outlook, volte e use
"Alterar no Outlook Classic".
"@, 'Assinatura DCBM', 'OK', 'Warning') | Out-Null
        return $false
    }

    return $true
}

function Invoke-ModoOffice365 {

    $tpl = Import-Templates

    if (-not (Initialize-ExchangeOnline)) { return }

    Write-Host 'Carregando usuarios...' -ForegroundColor Cyan

    $usuarios = Get-User -RecipientTypeDetails UserMailbox -ResultSize Unlimited |
        Where-Object { $_.WindowsEmailAddress } |
        Sort-Object DisplayName |
        ForEach-Object {
            [pscustomobject]@{
                Nome     = [string]$_.DisplayName
                Email    = [string]$_.WindowsEmailAddress
                Cargo    = [string]$_.Title
                Depto    = [string]$_.Department
                Celular  = [string]$_.MobilePhone
                Template = if ([string]::IsNullOrWhiteSpace([string]$_.MobilePhone)) { 'sem_celular' } else { 'com_celular' }
                Obj      = $_
            }
        }

    if (-not $usuarios) { throw 'Nenhum usuario com caixa postal encontrado.' }
    Write-Host ("{0} usuarios carregados." -f $usuarios.Count) -ForegroundColor Green

    # -----------------------------------------------------------------------
    # Interface
    # -----------------------------------------------------------------------

    $selecionados = New-Object 'System.Collections.Generic.HashSet[string]'
    $script:carregando = $false

    $form = New-Object System.Windows.Forms.Form
    $form.Text          = 'Assinatura DCBM - Office 365'
    $form.Size          = New-Object System.Drawing.Size(940, 640)
    $form.StartPosition = 'CenterScreen'
    $form.MinimumSize   = New-Object System.Drawing.Size(760, 480)

    $lblFiltro = New-Object System.Windows.Forms.Label
    $lblFiltro.Text     = 'Filtrar:'
    $lblFiltro.Location = New-Object System.Drawing.Point(12, 15)
    $lblFiltro.Size     = New-Object System.Drawing.Size(50, 20)
    $form.Controls.Add($lblFiltro)

    $txtFiltro = New-Object System.Windows.Forms.TextBox
    $txtFiltro.Location = New-Object System.Drawing.Point(62, 12)
    $txtFiltro.Size     = New-Object System.Drawing.Size(380, 24)
    $txtFiltro.Anchor   = 'Top,Left,Right'
    $form.Controls.Add($txtFiltro)

    $chkTodos = New-Object System.Windows.Forms.CheckBox
    $chkTodos.Text     = 'Marcar todos os visiveis'
    $chkTodos.Location = New-Object System.Drawing.Point(460, 13)
    $chkTodos.Size     = New-Object System.Drawing.Size(190, 22)
    $chkTodos.Anchor   = 'Top,Right'
    $form.Controls.Add($chkTodos)

    $lblCont = New-Object System.Windows.Forms.Label
    $lblCont.Location  = New-Object System.Drawing.Point(660, 15)
    $lblCont.Size      = New-Object System.Drawing.Size(250, 20)
    $lblCont.Anchor    = 'Top,Right'
    $lblCont.TextAlign = 'MiddleRight'
    $form.Controls.Add($lblCont)

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Location              = New-Object System.Drawing.Point(12, 45)
    $grid.Size                  = New-Object System.Drawing.Size(900, 490)
    $grid.Anchor                = 'Top,Bottom,Left,Right'
    $grid.AutoGenerateColumns   = $false
    $grid.AllowUserToAddRows    = $false
    $grid.AllowUserToDeleteRows = $false
    $grid.RowHeadersVisible     = $false
    $grid.SelectionMode         = 'FullRowSelect'
    $grid.MultiSelect           = $false
    $grid.BackgroundColor       = [System.Drawing.Color]::White
    $form.Controls.Add($grid)

    $colSel = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
    $colSel.HeaderText = ''
    $colSel.Name       = 'Sel'
    $colSel.Width      = 34
    $grid.Columns.Add($colSel) | Out-Null

    foreach ($c in @(
        @{N='Nome';     W=210},
        @{N='Email';    W=240},
        @{N='Cargo';    W=160},
        @{N='Depto';    W=140},
        @{N='Template'; W=100}
    )) {
        $col = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
        $col.HeaderText = $c.N
        $col.Name       = $c.N
        $col.Width      = $c.W
        $col.ReadOnly   = $true
        $grid.Columns.Add($col) | Out-Null
    }

    function Update-Contador {
        $lblCont.Text = "{0} selecionado(s) de {1}" -f $selecionados.Count, $usuarios.Count
    }

    function Popular-Grid {
        $script:carregando = $true
        $grid.Rows.Clear()

        $termo = $txtFiltro.Text.Trim()
        $lista = if ($termo) {
            $usuarios | Where-Object {
                $_.Nome  -like "*$termo*" -or $_.Email -like "*$termo*" -or
                $_.Cargo -like "*$termo*" -or $_.Depto -like "*$termo*"
            }
        } else { $usuarios }

        foreach ($u in $lista) {
            $idx = $grid.Rows.Add($selecionados.Contains($u.Email), $u.Nome, $u.Email, $u.Cargo, $u.Depto, $u.Template)
            $grid.Rows[$idx].Tag = $u
        }

        $script:carregando = $false
        Update-Contador
    }

    $grid.Add_CurrentCellDirtyStateChanged({
        if ($grid.IsCurrentCellDirty) { $grid.CommitEdit('Commit') }
    })

    $grid.Add_CellValueChanged({
        param($s, $e)
        if ($script:carregando -or $e.ColumnIndex -ne 0 -or $e.RowIndex -lt 0) { return }
        $u = $grid.Rows[$e.RowIndex].Tag
        if ($grid.Rows[$e.RowIndex].Cells[0].Value -eq $true) { [void]$selecionados.Add($u.Email) }
        else { [void]$selecionados.Remove($u.Email) }
        Update-Contador
    })

    $txtFiltro.Add_TextChanged({ Popular-Grid })

    $chkTodos.Add_CheckedChanged({
        if ($script:carregando) { return }
        $marcar = $chkTodos.Checked
        $script:carregando = $true
        foreach ($row in $grid.Rows) {
            $row.Cells[0].Value = $marcar
            if ($marcar) { [void]$selecionados.Add($row.Tag.Email) }
            else         { [void]$selecionados.Remove($row.Tag.Email) }
        }
        $script:carregando = $false
        Update-Contador
    })

    $btnSimular = New-Object System.Windows.Forms.Button
    $btnSimular.Text     = 'Simular (gera preview)'
    $btnSimular.Location = New-Object System.Drawing.Point(12, 550)
    $btnSimular.Size     = New-Object System.Drawing.Size(180, 34)
    $btnSimular.Anchor   = 'Bottom,Left'
    $form.Controls.Add($btnSimular)

    $btnAplicar = New-Object System.Windows.Forms.Button
    $btnAplicar.Text      = 'Aplicar assinatura'
    $btnAplicar.Location  = New-Object System.Drawing.Point(200, 550)
    $btnAplicar.Size      = New-Object System.Drawing.Size(160, 34)
    $btnAplicar.Anchor    = 'Bottom,Left'
    $btnAplicar.BackColor = [System.Drawing.Color]::FromArgb(242, 92, 39)
    $btnAplicar.ForeColor = [System.Drawing.Color]::White
    $btnAplicar.FlatStyle = 'Flat'
    $form.Controls.Add($btnAplicar)

    $btnLimpar = New-Object System.Windows.Forms.Button
    $btnLimpar.Text     = 'Remover assinatura'
    $btnLimpar.Location = New-Object System.Drawing.Point(368, 550)
    $btnLimpar.Size     = New-Object System.Drawing.Size(160, 34)
    $btnLimpar.Anchor   = 'Bottom,Left'
    $form.Controls.Add($btnLimpar)

    $btnFechar = New-Object System.Windows.Forms.Button
    $btnFechar.Text     = 'Fechar'
    $btnFechar.Location = New-Object System.Drawing.Point(812, 550)
    $btnFechar.Size     = New-Object System.Drawing.Size(100, 34)
    $btnFechar.Anchor   = 'Bottom,Right'
    $btnFechar.Add_Click({ $form.Close() })
    $form.Controls.Add($btnFechar)

    # -----------------------------------------------------------------------
    # Execucao
    # -----------------------------------------------------------------------

    function Executar {
        param([ValidateSet('Simular','Aplicar','Limpar')] [string] $Acao)

        if ($selecionados.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show('Nenhum usuario selecionado.', 'Assinatura DCBM',
                'OK', 'Warning') | Out-Null
            return
        }

        if ($Acao -ne 'Simular') {
            $verbo = if ($Acao -eq 'Limpar') { 'REMOVER a assinatura de' } else { 'aplicar a assinatura em' }
            $r = [System.Windows.Forms.MessageBox]::Show(
                "Confirma $verbo $($selecionados.Count) usuario(s)?", 'Assinatura DCBM', 'YesNo', 'Question')
            if ($r -ne 'Yes') { return }
        }

        $form.Cursor = 'WaitCursor'
        $alvos = $usuarios | Where-Object { $selecionados.Contains($_.Email) }
        $log   = New-Object System.Collections.Generic.List[object]

        foreach ($alvo in $alvos) {
            $reg = [ordered]@{
                Nome = $alvo.Nome; Email = $alvo.Email; Template = $alvo.Template
                Faltando = ''; Resultado = ''; Mensagem = ''
            }

            try {
                $mbx = Get-Mailbox -Identity $alvo.Email -ErrorAction Stop

                if ($Acao -eq 'Limpar') {
                    Set-MailboxMessageConfiguration -Identity $mbx.PrimarySmtpAddress `
                        -SignatureHtml '' -SignatureName '' `
                        -AutoAddSignature $false -AutoAddSignatureOnReply $false -ErrorAction Stop
                    $reg.Resultado = 'Removido'
                }
                else {
                    $u = $alvo.Obj
                    $campos = @{
                        '%%DisplayName%%'  = $mbx.DisplayName
                        '%%Title%%'        = $u.Title
                        '%%Department%%'   = $u.Department
                        '%%PhoneNumber%%'  = $u.Phone
                        '%%FaxNumber%%'    = $u.Fax
                        '%%MobileNumber%%' = $u.MobilePhone
                        '%%Email%%'        = $mbx.PrimarySmtpAddress
                        '%%Street%%'       = $u.StreetAddress
                        '%%City%%'         = $u.City
                        '%%State%%'        = $u.StateOrProvince
                        '%%Country%%'      = $u.CountryOrRegion
                        '%%ZipCode%%'      = $u.PostalCode
                    }

                    $sig = Build-Signature -Campos $campos -Templates $tpl
                    $reg.Faltando = $sig.Faltando
                    if ($sig.Sobrou) { throw 'Sobrou placeholder %% nao substituido.' }

                    $arq = Join-Path $PastaPreview ("{0}.html" -f ($alvo.Email -replace '[^\w\.\-]', '_'))
                    Set-Content -LiteralPath $arq -Value $sig.Html -Encoding UTF8

                    if ($Acao -eq 'Simular') {
                        $reg.Resultado = 'Simulado'
                    }
                    else {
                        Set-MailboxMessageConfiguration -Identity $mbx.PrimarySmtpAddress `
                            -SignatureName $NomeAssinatura -SignatureHtml $sig.Html `
                            -AutoAddSignature $true -AutoAddSignatureOnReply $true -ErrorAction Stop

                        $gravado = (Get-MailboxMessageConfiguration -Identity $mbx.PrimarySmtpAddress).SignatureHtml
                        $ok  = ([regex]::Matches($gravado,  'src="https://')).Count
                        $tot = ([regex]::Matches($sig.Html, 'src="https://')).Count

                        if ($ok -lt $tot) {
                            $reg.Resultado = 'ATENCAO'
                            $reg.Mensagem  = "Imagens gravadas: $ok de $tot"
                        } else {
                            $reg.Resultado = 'Gravado'
                        }
                    }
                }
            }
            catch {
                $reg.Resultado = 'ERRO'
                $reg.Mensagem  = $_.Exception.Message
            }

            $log.Add([pscustomobject]$reg)
        }

        $form.Cursor = 'Default'

        $arqLog = Write-Log -Registros $log -Rotulo $Acao

        $okC  = @($log | Where-Object Resultado -in 'Gravado','Removido','Simulado').Count
        $atC  = @($log | Where-Object Resultado -eq 'ATENCAO').Count
        $erC  = @($log | Where-Object Resultado -eq 'ERRO').Count
        $falt = @($log | Where-Object { $_.Faltando }).Count

        $msg = @"
Processados: $($log.Count)
Sucesso    : $okC
Atencao    : $atC
Erros      : $erC

Cadastros incompletos: $falt
Log: $arqLog
"@
        if ($Acao -eq 'Simular') { $msg += "`nPreviews: $PastaPreview" }

        [System.Windows.Forms.MessageBox]::Show($msg, 'Assinatura DCBM', 'OK',
            $(if ($erC) { 'Warning' } else { 'Information' })) | Out-Null
    }

    $btnSimular.Add_Click({ Executar -Acao 'Simular' })
    $btnAplicar.Add_Click({ Executar -Acao 'Aplicar' })
    $btnLimpar.Add_Click({  Executar -Acao 'Limpar'  })

    Popular-Grid
    [void]$form.ShowDialog()
}

# ---------------------------------------------------------------------------
# Modo 2 - Outlook Classic
# ---------------------------------------------------------------------------

function Invoke-ModoClassic {

    $tpl = Import-Templates
    $log = New-Object System.Collections.Generic.List[object]

    $reg = [ordered]@{
        Usuario = $env:USERNAME; Nome = ''; Email = ''; Template = ''
        Faltando = ''; Resultado = ''; Mensagem = ''
    }

    try {
        $busca  = [ADSISearcher]"(&(objectCategory=user)(samaccountname=$env:USERNAME))"
        $achado = $busca.FindOne()
        if (-not $achado) { throw "Usuario '$env:USERNAME' nao encontrado no AD." }
        Write-Host 'AD: OK' -ForegroundColor Green

        $p = $achado.Properties
        function V([string]$c) { if ($p.$c) { [string]$p.$c[0] } else { '' } }

        $campos = @{
            '%%DisplayName%%'  = (V 'displayname')
            '%%Title%%'        = (V 'title')
            '%%Department%%'   = (V 'department')
            '%%PhoneNumber%%'  = (V 'telephonenumber')
            '%%FaxNumber%%'    = (V 'facsimiletelephonenumber')
            '%%MobileNumber%%' = (V 'mobile')
            '%%Email%%'        = (V 'mail')
            '%%Street%%'       = (V 'streetaddress')
            '%%City%%'         = (V 'l')
            '%%State%%'        = (V 'st')
            '%%Country%%'      = (V 'co')
            '%%ZipCode%%'      = (V 'postalcode')
        }

        $reg.Nome  = $campos['%%DisplayName%%']
        $reg.Email = $campos['%%Email%%']

        Write-Host ("Nome    : {0}" -f $campos['%%DisplayName%%'])
        Write-Host ("Celular : '{0}'" -f $campos['%%MobileNumber%%'])

        if ([string]::IsNullOrWhiteSpace($campos['%%Email%%'])) {
            throw 'Usuario sem e-mail no AD.'
        }

        $sig = Build-Signature -Campos $campos -Templates $tpl
        $reg.Template = if ($sig.TemCelular) { 'com_celular' } else { 'sem_celular' }
        $reg.Faltando = $sig.Faltando

        Write-Host ("Template: {0}" -f $reg.Template)

        if ($sig.Sobrou) {
            $sobrou = (([regex]::Matches($sig.Html, '%%\w+%%') | ForEach-Object { $_.Value }) |
                        Select-Object -Unique) -join ', '
            throw "Sobrou placeholder nao substituido: $sobrou"
        }
        Write-Host ("HTML: OK ({0} caracteres)" -f $sig.Html.Length) -ForegroundColor Green

        # Preview, para conferencia
        $arqPrev = Join-Path $PastaPreview ("{0}.html" -f ($env:USERNAME -replace '[^\w\.\-]', '_'))
        Set-Content -LiteralPath $arqPrev -Value $sig.Html -Encoding UTF8

        # Instalacao no perfil
        $destino = Join-Path $env:APPDATA 'Microsoft\Signatures'
        New-Item -ItemType Directory -Path $destino -Force | Out-Null
        Set-Content -LiteralPath (Join-Path $destino "$NomeAssinatura.htm") -Value $sig.Html -Encoding UTF8

        # O Outlook classico so usa o arquivo local com o roaming desligado nesta maquina
        $setup = 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Setup'
        New-Item -Path $setup -Force | Out-Null
        Set-ItemProperty -Path $setup -Name DisableRoamingSignaturesTemporaryToggle -Value 1 -Type DWord

        $mail = 'HKCU:\Software\Microsoft\Office\16.0\Common\MailSettings'
        New-Item -Path $mail -Force | Out-Null
        Set-ItemProperty -Path $mail -Name NewSignature   -Value $NomeAssinatura -Type String
        Set-ItemProperty -Path $mail -Name ReplySignature -Value $NomeAssinatura -Type String

        $reg.Resultado = 'Instalado'
        $reg.Mensagem  = $destino

        Write-Host ("INSTALADO em {0}" -f $destino) -ForegroundColor Green
        Get-ChildItem -LiteralPath $destino | Select-Object Name, Length | Format-Table -AutoSize | Out-String | Write-Host
    }
    catch {
        $reg.Resultado = 'ERRO'
        $reg.Mensagem  = $_.Exception.Message
        Write-Host ("PAROU: {0}" -f $_.Exception.Message) -ForegroundColor Red
    }

    $log.Add([pscustomobject]$reg)
    $arqLog = Write-Log -Registros $log -Rotulo 'classic'

    $msg = if ($reg.Resultado -eq 'Instalado') {
@"
Assinatura instalada nesta maquina.

Usuario : $($reg.Nome)
E-mail  : $($reg.Email)
Modelo  : $($reg.Template)
Pasta   : $($reg.Mensagem)

Feche e reabra o Outlook para ver a assinatura.
Log: $arqLog
"@
    } else {
@"
Nao foi possivel instalar.

$($reg.Mensagem)

Log: $arqLog
"@
    }

    [System.Windows.Forms.MessageBox]::Show($msg, 'Assinatura DCBM', 'OK',
        $(if ($reg.Resultado -eq 'Instalado') { 'Information' } else { 'Warning' })) | Out-Null
}

# ---------------------------------------------------------------------------
# Modo 3 - Limpar cache do Office
# ---------------------------------------------------------------------------

function Invoke-LimparCache {
    <#
      Limpa o cache do Outlook novo e do Outlook classico nesta maquina.

      NAO remove arquivos .ost nem a pasta Signatures. O .ost e a copia local da
      caixa: apaga-lo obriga a ressincronizar tudo, o que e demorado e nao ajuda
      em problema de assinatura. Signatures nao e cache - apagar removeria a
      propria assinatura instalada.
    #>

    $itens = @(
        @{ Rotulo='Outlook novo - Olk';        Caminho="$env:LOCALAPPDATA\Microsoft\Olk" },
        @{ Rotulo='Outlook novo - LocalCache'; Caminho="$env:LOCALAPPDATA\Packages\Microsoft.OutlookForWindows_8wekyb3d8bbwe\LocalCache" },
        @{ Rotulo='Classico - RoamCache';      Caminho="$env:LOCALAPPDATA\Microsoft\Outlook\RoamCache" },
        @{ Rotulo='Classico - arquivos temp';  Caminho="$env:LOCALAPPDATA\Microsoft\Windows\INetCache\Content.Outlook" },
        @{ Rotulo='Classico - formularios';    Caminho="$env:LOCALAPPDATA\Microsoft\FORMS" }
    )

    # Previa do que existe e quanto ocupa
    $encontrados = @()
    foreach ($i in $itens) {
        if (Test-Path -LiteralPath $i.Caminho) {
            $tam = 0
            try {
                $tam = (Get-ChildItem -LiteralPath $i.Caminho -Recurse -File -Force -ErrorAction SilentlyContinue |
                        Measure-Object -Property Length -Sum).Sum
            } catch { }
            $encontrados += [pscustomobject]@{ Rotulo=$i.Rotulo; Caminho=$i.Caminho; Bytes=[long]$tam }
        }
    }

    if ($encontrados.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            'Nenhuma pasta de cache encontrada nesta maquina. Nada a limpar.',
            'Limpar Cache Office', 'OK', 'Information') | Out-Null
        return
    }

    $lista = ($encontrados | ForEach-Object {
        "  - {0}  ({1:N1} MB)" -f $_.Rotulo, ($_.Bytes / 1MB)
    }) -join [Environment]::NewLine

    $totalMb = ($encontrados | Measure-Object -Property Bytes -Sum).Sum / 1MB

    $confirma = [System.Windows.Forms.MessageBox]::Show(
@"
O Outlook sera FECHADO e as pastas abaixo serao removidas:

$lista

Total: $([math]::Round($totalMb,1)) MB

Nao serao tocados: arquivos .ost e a pasta Signatures.

Confirma?
"@, 'Limpar Cache Office', 'YesNo', 'Warning')

    if ($confirma -ne 'Yes') { return }

    $log = New-Object System.Collections.Generic.List[object]

    # Fecha os dois Outlooks
    foreach ($proc in @('olk','OUTLOOK')) {
        $p = Get-Process -Name $proc -ErrorAction SilentlyContinue
        if ($p) {
            Write-Host ("Fechando {0} ({1} processo(s))..." -f $proc, $p.Count) -ForegroundColor Yellow
            $p | Stop-Process -Force -ErrorAction SilentlyContinue
            $log.Add([pscustomobject]@{ Item="Processo $proc"; Caminho=''; MB=''; Resultado='Encerrado'; Mensagem='' })
        }
    }
    Start-Sleep -Seconds 3

    foreach ($e in $encontrados) {
        $reg = [ordered]@{
            Item = $e.Rotulo; Caminho = $e.Caminho
            MB = [math]::Round($e.Bytes / 1MB, 2); Resultado = ''; Mensagem = ''
        }
        try {
            Remove-Item -LiteralPath $e.Caminho -Recurse -Force -ErrorAction Stop
            $reg.Resultado = 'Removido'
            Write-Host ("  removido: {0}" -f $e.Rotulo) -ForegroundColor Green
        }
        catch {
            # Remocao parcial e comum quando algum arquivo segue em uso
            if (Test-Path -LiteralPath $e.Caminho) {
                $reg.Resultado = 'PARCIAL'
                $reg.Mensagem  = $_.Exception.Message
                Write-Host ("  parcial: {0} - {1}" -f $e.Rotulo, $_.Exception.Message) -ForegroundColor Yellow
            } else {
                $reg.Resultado = 'Removido'
                Write-Host ("  removido: {0}" -f $e.Rotulo) -ForegroundColor Green
            }
        }
        $log.Add([pscustomobject]$reg)
    }

    $arqLog = Write-Log -Registros $log -Rotulo 'cache'

    $rem = @($log | Where-Object Resultado -eq 'Removido').Count
    $par = @($log | Where-Object Resultado -eq 'PARCIAL').Count

    [System.Windows.Forms.MessageBox]::Show(
@"
Limpeza concluida.

Removidos : $rem
Parciais  : $par
Liberado  : $([math]::Round($totalMb,1)) MB

Abra o Outlook novamente. A primeira abertura sera mais lenta,
pois o cache precisa ser reconstruido.

Log: $arqLog
"@, 'Limpar Cache Office', 'OK',
        $(if ($par) { 'Warning' } else { 'Information' })) | Out-Null
}

# ---------------------------------------------------------------------------
# Inicio
# ---------------------------------------------------------------------------

function Invoke-Modo {
    param([string]$Escolha)
    switch ($Escolha) {
        'Office365' { Invoke-ModoOffice365 }
        'Classic'   { Invoke-ModoClassic }
        'Cache'     { Invoke-LimparCache }
    }
}

if ($Modo -ne 'Menu') {
    Invoke-Modo -Escolha $Modo
}
else {
    # Volta ao menu depois de cada operacao, ate escolherem Sair
    do {
        $escolha = Show-Menu
        if ($escolha) {
            try   { Invoke-Modo -Escolha $escolha }
            catch {
                Write-Host ("ERRO: {0}" -f $_.Exception.Message) -ForegroundColor Red
                [System.Windows.Forms.MessageBox]::Show(
                    $_.Exception.Message, 'Assinatura DCBM', 'OK', 'Error') | Out-Null
            }
        }
    } while ($escolha)

    Write-Host 'Encerrado.' -ForegroundColor Yellow
}
