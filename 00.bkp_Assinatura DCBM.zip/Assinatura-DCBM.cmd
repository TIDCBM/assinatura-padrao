@echo off
rem ---------------------------------------------------------------------------
rem  Assinatura DCBM - execucao COM janela de console
rem
rem  Use este arquivo quando quiser acompanhar as mensagens na tela, por
rem  exemplo ao investigar um problema.
rem
rem  Para o uso normal, sem janela preta, use o Assinatura-DCBM.vbs.
rem ---------------------------------------------------------------------------
title Assinatura DCBM

cd /d "%~dp0"

if not exist "Assinatura-DCBM.ps1" (
    echo.
    echo  ERRO: Assinatura-DCBM.ps1 nao encontrado nesta pasta.
    echo  Pasta atual: %CD%
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File ".\Assinatura-DCBM.ps1"

if errorlevel 1 (
    echo.
    echo  O script terminou com erro. Confira as mensagens acima.
    echo.
    pause
)
