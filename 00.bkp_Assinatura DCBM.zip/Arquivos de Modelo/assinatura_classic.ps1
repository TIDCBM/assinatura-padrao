$compartilhamento = 'I:\02. PROCEDIMENTOS DCBM\TI\ASSINATURAS'
$grupoRestricao   = ''

$busca = [ADSISearcher]"(&(objectCategory=user)(samaccountname=$env:USERNAME))"
$achado = $busca.FindOne()
if (-not $achado) { Write-Host "PAROU: usuario nao encontrado no AD" -f Red; return }
Write-Host "AD: OK" -f Green

$p = $achado.Properties
function V($c) { if ($p.$c) { [string]$p.$c[0] } else { '' } }

Write-Host "Nome    : $(V 'displayname')"
Write-Host "Celular : '$(V 'mobile')'"

$arquivo  = if ([string]::IsNullOrWhiteSpace((V 'mobile'))) { 'sem_celular.html' } else { 'com_celular.html' }
$template = Join-Path $compartilhamento $arquivo
Write-Host "Template: $template"

if (-not (Test-Path -LiteralPath $template)) { Write-Host "PAROU: template nao existe" -f Red; return }
Write-Host "Template: OK" -f Green

$html = Get-Content -LiteralPath $template -Raw -Encoding UTF8
$html = $html.
    Replace('%%DisplayName%%',  (V 'displayname')).
    Replace('%%Title%%',        (V 'title')).
    Replace('%%Department%%',   (V 'department')).
    Replace('%%PhoneNumber%%',  (V 'telephonenumber')).
    Replace('%%FaxNumber%%',    (V 'facsimiletelephonenumber')).
    Replace('%%MobileNumber%%', (V 'mobile')).
    Replace('%%Email%%',        (V 'mail')).
    Replace('%%Street%%',       (V 'streetaddress')).
    Replace('%%City%%',         (V 'l')).
    Replace('%%State%%',        (V 'st')).
    Replace('%%Country%%',      (V 'co')).
    Replace('%%ZipCode%%',      (V 'postalcode'))

if ([string]::IsNullOrWhiteSpace((V 'facsimiletelephonenumber'))) {
    $html = $html -replace '\s*Ext\.\s*(?=<)', ''
}

if ($html -match '%%') {
    Write-Host "PAROU: sobrou placeholder ->" -f Red
    ([regex]::Matches($html, '%%\w+%%') | ForEach-Object { $_.Value } | Select-Object -Unique) -join ', '
    return
}
Write-Host "HTML: OK ($($html.Length) caracteres)" -f Green

$destino = Join-Path $env:APPDATA 'Microsoft\Signatures'
New-Item -ItemType Directory -Path $destino -Force | Out-Null
Set-Content -LiteralPath (Join-Path $destino "DCBM.htm") -Value $html -Encoding UTF8

$setup = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Setup"
New-Item -Path $setup -Force | Out-Null
Set-ItemProperty -Path $setup -Name DisableRoamingSignaturesTemporaryToggle -Value 1 -Type DWord

$mail = "HKCU:\Software\Microsoft\Office\16.0\Common\MailSettings"
New-Item -Path $mail -Force | Out-Null
Set-ItemProperty -Path $mail -Name NewSignature   -Value 'DCBM' -Type String
Set-ItemProperty -Path $mail -Name ReplySignature -Value 'DCBM' -Type String

Write-Host "INSTALADO em $destino" -f Green
Get-ChildItem $destino