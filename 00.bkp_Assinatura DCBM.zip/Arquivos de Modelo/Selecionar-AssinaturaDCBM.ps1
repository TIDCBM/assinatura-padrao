<#
.SYNOPSIS
    Interface grafica para selecionar usuarios e aplicar a assinatura padronizada DCBM.

.DESCRIPTION
    Carrega os usuarios com caixa postal do Exchange Online, mostra numa lista com
    caixas de selecao e aplica a assinatura apenas nos marcados.

    O template e escolhido automaticamente pelo atributo de celular do diretorio:
    preenchido  -> com_celular.html
    vazio       -> sem_celular.html

    IMPORTANTE: as imagens devem estar referenciadas por URL https no template.
    O Exchange esvazia o src de imagens em base64.

.EXAMPLE
    .\Selecionar-AssinaturaDCBM.ps1
#>

[CmdletBinding()]
param(
    [string] $TemplateComCelular = 'I:\02. PROCEDIMENTOS DCBM\TI\ASSINATURAS\com_celular.html',
    [string] $TemplateSemCelular = 'I:\02. PROCEDIMENTOS DCBM\TI\ASSINATURAS\sem_celular.html',
    [string] $NomeAssinatura     = 'DCBM',
    [string] $PreviewPath        = 'I:\02. PROCEDIMENTOS DCBM\TI\ASSINATURAS\preview',
    [string] $LogPath            = 'I:\02. PROCEDIMENTOS DCBM\TI\ASSINATURAS'
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------

function Get-Template {
    param([string]$Path, [string]$Rotulo)

    if (-not (Test-Path -LiteralPath $Path)) { throw "Template '$Rotulo' nao encontrado: $Path" }
    $txt = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($txt))  { throw "Template '$Rotulo' esta vazio: $Path" }
    if ($txt -notmatch '%%DisplayName%%')    { throw "Template '$Rotulo' nao contem %%DisplayName%%: $Path" }
    if ($txt -match 'src="data:image')       { throw "Template '$Rotulo' usa base64. O Exchange apaga o src. Use URL https." }
    return $txt
}

$tpl = @{
    ComCelular = Get-Template -Path $TemplateComCelular -Rotulo 'com celular'
    SemCelular = Get-Template -Path $TemplateSemCelular -Rotulo 'sem celular'
}

# ---------------------------------------------------------------------------
# Conexao
# ---------------------------------------------------------------------------

if (-not (Get-Command Get-Mailbox -ErrorAction SilentlyContinue)) {
    Write-Host 'Conectando ao Exchange Online...' -ForegroundColor Cyan
    Import-Module ExchangeOnlineManagement
    Connect-ExchangeOnline -ShowBanner:$false
}

Write-Host 'Carregando usuarios...' -ForegroundColor Cyan

$usuarios = Get-User -RecipientTypeDetails UserMailbox -ResultSize Unlimited |
    Where-Object { $_.WindowsEmailAddress } |
    Sort-Object DisplayName |
    ForEach-Object {
        [pscustomobject]@{
            Nome       = [string]$_.DisplayName
            Email      = [string]$_.WindowsEmailAddress
            Cargo      = [string]$_.Title
            Depto      = [string]$_.Department
            Celular    = [string]$_.MobilePhone
            Template   = if ([string]::IsNullOrWhiteSpace([string]$_.MobilePhone)) { 'sem_celular' } else { 'com_celular' }
            Obj        = $_
        }
    }

if (-not $usuarios) { throw 'Nenhum usuario com caixa postal encontrado.' }
Write-Host ("{0} usuarios carregados." -f $usuarios.Count) -ForegroundColor Green

# ---------------------------------------------------------------------------
# Montagem do HTML
# ---------------------------------------------------------------------------

function ConvertTo-SafeHtml {
    param([object]$Valor)
    if ($null -eq $Valor) { return '' }
    return [System.Net.WebUtility]::HtmlEncode([string]$Valor)
}

function Build-Signature {
    param($Caixa, $Usuario)

    $temCelular = -not [string]::IsNullOrWhiteSpace([string]$Usuario.MobilePhone)
    $html = if ($temCelular) { $tpl['ComCelular'] } else { $tpl['SemCelular'] }

    $mapa = [ordered]@{
        '%%DisplayName%%'  = $Caixa.DisplayName
        '%%Title%%'        = $Usuario.Title
        '%%Department%%'   = $Usuario.Department
        '%%PhoneNumber%%'  = $Usuario.Phone
        '%%FaxNumber%%'    = $Usuario.Fax
        '%%MobileNumber%%' = $Usuario.MobilePhone
        '%%Email%%'        = $Caixa.PrimarySmtpAddress
        '%%Street%%'       = $Usuario.StreetAddress
        '%%City%%'         = $Usuario.City
        '%%State%%'        = $Usuario.StateOrProvince
        '%%Country%%'      = $Usuario.CountryOrRegion
        '%%ZipCode%%'      = $Usuario.PostalCode
    }

    $faltando = @()
    foreach ($chave in $mapa.Keys) {
        if ($chave -eq '%%MobileNumber%%' -and -not $temCelular) { continue }
        if ([string]::IsNullOrWhiteSpace([string]$mapa[$chave])) { $faltando += $chave.Trim('%') }
        $html = $html.Replace($chave, (ConvertTo-SafeHtml $mapa[$chave]))
    }

    if ([string]::IsNullOrWhiteSpace([string]$Usuario.Fax)) {
        $html = $html -replace '\s*Ext\.\s*(?=<)', ''
    }

    return [pscustomobject]@{
        Html       = $html
        TemCelular = $temCelular
        Faltando   = ($faltando -join '; ')
        Sobrou     = ($html -match '%%')
    }
}

# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------

$selecionados = New-Object 'System.Collections.Generic.HashSet[string]'
$script:carregando = $false

$form = New-Object System.Windows.Forms.Form
$form.Text          = 'Assinatura DCBM - selecionar usuarios'
$form.Size          = New-Object System.Drawing.Size(940, 640)
$form.StartPosition = 'CenterScreen'
$form.MinimumSize   = New-Object System.Drawing.Size(760, 480)

$lblFiltro = New-Object System.Windows.Forms.Label
$lblFiltro.Text     = 'Filtrar:'
$lblFiltro.Location = New-Object System.Drawing.Point(12, 15)
$lblFiltro.Size     = New-Object System.Drawing.Size(50, 20)
$form.Controls.Add($lblFiltro)

$txtFiltro = New-Object System.Windows.Forms.TextBox
$txtFiltro.Location = New-Object System.Drawing.Point(62, 12)
$txtFiltro.Size     = New-Object System.Drawing.Size(380, 24)
$txtFiltro.Anchor   = 'Top,Left,Right'
$form.Controls.Add($txtFiltro)

$chkTodos = New-Object System.Windows.Forms.CheckBox
$chkTodos.Text     = 'Marcar todos os visiveis'
$chkTodos.Location = New-Object System.Drawing.Point(460, 13)
$chkTodos.Size     = New-Object System.Drawing.Size(190, 22)
$chkTodos.Anchor   = 'Top,Right'
$form.Controls.Add($chkTodos)

$lblCont = New-Object System.Windows.Forms.Label
$lblCont.Location  = New-Object System.Drawing.Point(660, 15)
$lblCont.Size      = New-Object System.Drawing.Size(250, 20)
$lblCont.Anchor    = 'Top,Right'
$lblCont.TextAlign = 'MiddleRight'
$form.Controls.Add($lblCont)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location             = New-Object System.Drawing.Point(12, 45)
$grid.Size                 = New-Object System.Drawing.Size(900, 490)
$grid.Anchor               = 'Top,Bottom,Left,Right'
$grid.AutoGenerateColumns  = $false
$grid.AllowUserToAddRows   = $false
$grid.AllowUserToDeleteRows= $false
$grid.RowHeadersVisible    = $false
$grid.SelectionMode        = 'FullRowSelect'
$grid.MultiSelect          = $false
$grid.BackgroundColor      = [System.Drawing.Color]::White
$form.Controls.Add($grid)

$colSel = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colSel.HeaderText = ''
$colSel.Name       = 'Sel'
$colSel.Width      = 34
$grid.Columns.Add($colSel) | Out-Null

foreach ($c in @(
    @{N='Nome';  W=210},
    @{N='Email'; W=240},
    @{N='Cargo'; W=160},
    @{N='Depto'; W=140},
    @{N='Template'; W=100}
)) {
    $col = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $col.HeaderText = $c.N
    $col.Name       = $c.N
    $col.Width      = $c.W
    $col.ReadOnly   = $true
    $grid.Columns.Add($col) | Out-Null
}

function Update-Contador {
    $lblCont.Text = "{0} selecionado(s) de {1}" -f $selecionados.Count, $usuarios.Count
}

function Popular-Grid {
    $script:carregando = $true
    $grid.Rows.Clear()

    $termo = $txtFiltro.Text.Trim()
    $lista = if ($termo) {
        $usuarios | Where-Object {
            $_.Nome  -like "*$termo*" -or $_.Email -like "*$termo*" -or
            $_.Cargo -like "*$termo*" -or $_.Depto -like "*$termo*"
        }
    } else { $usuarios }

    foreach ($u in $lista) {
        $idx = $grid.Rows.Add($selecionados.Contains($u.Email), $u.Nome, $u.Email, $u.Cargo, $u.Depto, $u.Template)
        $grid.Rows[$idx].Tag = $u
    }

    $script:carregando = $false
    Update-Contador
}

$grid.Add_CurrentCellDirtyStateChanged({
    if ($grid.IsCurrentCellDirty) { $grid.CommitEdit('Commit') }
})

$grid.Add_CellValueChanged({
    param($s, $e)
    if ($script:carregando -or $e.ColumnIndex -ne 0 -or $e.RowIndex -lt 0) { return }
    $u = $grid.Rows[$e.RowIndex].Tag
    if ($grid.Rows[$e.RowIndex].Cells[0].Value -eq $true) {
        [void]$selecionados.Add($u.Email)
    } else {
        [void]$selecionados.Remove($u.Email)
    }
    Update-Contador
})

$txtFiltro.Add_TextChanged({ Popular-Grid })

$chkTodos.Add_CheckedChanged({
    if ($script:carregando) { return }
    $marcar = $chkTodos.Checked
    $script:carregando = $true
    foreach ($row in $grid.Rows) {
        $row.Cells[0].Value = $marcar
        if ($marcar) { [void]$selecionados.Add($row.Tag.Email) }
        else         { [void]$selecionados.Remove($row.Tag.Email) }
    }
    $script:carregando = $false
    Update-Contador
})

$btnSimular = New-Object System.Windows.Forms.Button
$btnSimular.Text     = 'Simular (gera preview)'
$btnSimular.Location = New-Object System.Drawing.Point(12, 550)
$btnSimular.Size     = New-Object System.Drawing.Size(180, 34)
$btnSimular.Anchor   = 'Bottom,Left'
$form.Controls.Add($btnSimular)

$btnAplicar = New-Object System.Windows.Forms.Button
$btnAplicar.Text     = 'Aplicar assinatura'
$btnAplicar.Location = New-Object System.Drawing.Point(200, 550)
$btnAplicar.Size     = New-Object System.Drawing.Size(160, 34)
$btnAplicar.Anchor   = 'Bottom,Left'
$btnAplicar.BackColor= [System.Drawing.Color]::FromArgb(242, 92, 39)
$btnAplicar.ForeColor= [System.Drawing.Color]::White
$btnAplicar.FlatStyle= 'Flat'
$form.Controls.Add($btnAplicar)

$btnLimpar = New-Object System.Windows.Forms.Button
$btnLimpar.Text     = 'Remover assinatura'
$btnLimpar.Location = New-Object System.Drawing.Point(368, 550)
$btnLimpar.Size     = New-Object System.Drawing.Size(160, 34)
$btnLimpar.Anchor   = 'Bottom,Left'
$form.Controls.Add($btnLimpar)

$btnFechar = New-Object System.Windows.Forms.Button
$btnFechar.Text     = 'Fechar'
$btnFechar.Location = New-Object System.Drawing.Point(812, 550)
$btnFechar.Size     = New-Object System.Drawing.Size(100, 34)
$btnFechar.Anchor   = 'Bottom,Right'
$btnFechar.Add_Click({ $form.Close() })
$form.Controls.Add($btnFechar)

# ---------------------------------------------------------------------------
# Execucao
# ---------------------------------------------------------------------------

function Executar {
    param([ValidateSet('Simular','Aplicar','Limpar')] [string] $Modo)

    if ($selecionados.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Nenhum usuario selecionado.', 'Assinatura DCBM',
            'OK', 'Warning') | Out-Null
        return
    }

    if ($Modo -ne 'Simular') {
        $verbo = if ($Modo -eq 'Limpar') { 'REMOVER a assinatura de' } else { 'aplicar a assinatura em' }
        $r = [System.Windows.Forms.MessageBox]::Show(
            "Confirma $verbo $($selecionados.Count) usuario(s)?", 'Assinatura DCBM', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return }
    }

    if (-not (Test-Path -LiteralPath $PreviewPath)) {
        New-Item -ItemType Directory -Path $PreviewPath -Force | Out-Null
    }

    $form.Cursor = 'WaitCursor'
    $alvos = $usuarios | Where-Object { $selecionados.Contains($_.Email) }
    $log   = New-Object System.Collections.Generic.List[object]

    foreach ($alvo in $alvos) {
        $reg = [ordered]@{
            Nome = $alvo.Nome; Email = $alvo.Email; Template = $alvo.Template
            Faltando = ''; Resultado = ''; Mensagem = ''
        }

        try {
            $mbx = Get-Mailbox -Identity $alvo.Email -ErrorAction Stop

            if ($Modo -eq 'Limpar') {
                Set-MailboxMessageConfiguration -Identity $mbx.PrimarySmtpAddress `
                    -SignatureHtml '' -SignatureName '' `
                    -AutoAddSignature $false -AutoAddSignatureOnReply $false -ErrorAction Stop
                $reg.Resultado = 'Removido'
            }
            else {
                $sig = Build-Signature -Caixa $mbx -Usuario $alvo.Obj
                $reg.Faltando = $sig.Faltando
                if ($sig.Sobrou) { throw 'Sobrou placeholder %% nao substituido.' }

                $arq = Join-Path $PreviewPath ("{0}.html" -f ($alvo.Email -replace '[^\w\.\-]', '_'))
                Set-Content -LiteralPath $arq -Value $sig.Html -Encoding UTF8

                if ($Modo -eq 'Simular') {
                    $reg.Resultado = 'Simulado'
                }
                else {
                    Set-MailboxMessageConfiguration -Identity $mbx.PrimarySmtpAddress `
                        -SignatureName $NomeAssinatura -SignatureHtml $sig.Html `
                        -AutoAddSignature $true -AutoAddSignatureOnReply $true -ErrorAction Stop

                    $gravado = (Get-MailboxMessageConfiguration -Identity $mbx.PrimarySmtpAddress).SignatureHtml
                    $ok  = ([regex]::Matches($gravado,   'src="https://')).Count
                    $tot = ([regex]::Matches($sig.Html,  'src="https://')).Count

                    if ($ok -lt $tot) {
                        $reg.Resultado = 'ATENCAO'
                        $reg.Mensagem  = "Imagens gravadas: $ok de $tot"
                    } else {
                        $reg.Resultado = 'Gravado'
                    }
                }
            }
        }
        catch {
            $reg.Resultado = 'ERRO'
            $reg.Mensagem  = $_.Exception.Message
        }

        $log.Add([pscustomobject]$reg)
    }

    $form.Cursor = 'Default'

    $arqLog = Join-Path $LogPath ("log_{0}_{1}.csv" -f $Modo.ToLower(), (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $log | Export-Csv -LiteralPath $arqLog -NoTypeInformation -Encoding UTF8

    $okC  = @($log | Where-Object Resultado -in 'Gravado','Removido','Simulado').Count
    $atC  = @($log | Where-Object Resultado -eq 'ATENCAO').Count
    $erC  = @($log | Where-Object Resultado -eq 'ERRO').Count
    $falt = @($log | Where-Object { $_.Faltando }).Count

    $msg = @"
Processados: $($log.Count)
Sucesso    : $okC
Atencao    : $atC
Erros      : $erC

Cadastros incompletos: $falt
Log: $arqLog
"@
    if ($Modo -eq 'Simular') { $msg += "`nPreviews: $PreviewPath" }

    [System.Windows.Forms.MessageBox]::Show($msg, 'Assinatura DCBM', 'OK',
        $(if ($erC) { 'Warning' } else { 'Information' })) | Out-Null
}

$btnSimular.Add_Click({ Executar -Modo 'Simular' })
$btnAplicar.Add_Click({ Executar -Modo 'Aplicar' })
$btnLimpar.Add_Click({  Executar -Modo 'Limpar'  })

Popular-Grid
[void]$form.ShowDialog()
